declare function soby_CamlBuilder(listName: any, viewName: any, rowLimit: any, webUrl: any): void;
declare var sobyObject: () => void;
declare var soby: any;
