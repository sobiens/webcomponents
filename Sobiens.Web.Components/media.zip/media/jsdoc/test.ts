﻿/**
 * Class representing a dot.
 */
class soby_test
{
}