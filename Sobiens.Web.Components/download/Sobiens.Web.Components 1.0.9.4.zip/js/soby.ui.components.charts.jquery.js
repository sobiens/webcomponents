﻿$.fn.sobychart = function () {
    sobyGenerateChartFromHtmlElement(this.attr("id"));
};
