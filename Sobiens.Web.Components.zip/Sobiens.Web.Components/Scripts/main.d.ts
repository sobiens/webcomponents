declare function soby_ShowHideViewSource(): void;
declare function soby_ShowHideViewCode(containerId: any, codeFile: any): void;
declare function soby_GetTutorialWebAPIUrl(): string;
declare function soby_GetTutorialWCFUrl(): string;
