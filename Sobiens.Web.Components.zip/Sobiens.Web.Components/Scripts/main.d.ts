declare function soby_ShowHideViewSource(): void;
declare function soby_ShowHideViewCode(containerId: any, codeFile: any): void;
declare function soby_GetTutorialWebAPIUrl(): "http://webcomponentsservices.sobiens.com/api" | "https://webcomponentsservices.sobiens.com/api" | "http://localhost:7287/api";
declare function soby_GetTutorialWCFUrl(): "http://webcomponentsservices.sobiens.com/wcf" | "https://webcomponentsservices.sobiens.com/wcf" | "http://localhost:7287/wcf";
