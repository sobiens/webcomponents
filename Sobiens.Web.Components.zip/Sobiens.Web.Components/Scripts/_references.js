﻿/// <reference path="modernizr-2.8.3.js" />
/// <reference path="jquery-ui-1.12.0.js" />
/// <reference path="jquery-3.1.0.js" />
