declare function soby_PopulateSPHeader(): void;
