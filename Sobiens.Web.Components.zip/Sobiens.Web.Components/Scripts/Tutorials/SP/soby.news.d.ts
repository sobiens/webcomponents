declare function soby_PopulateNews(): void;
declare function soby_PopulateSPNewsImages(itemID: any): void;
