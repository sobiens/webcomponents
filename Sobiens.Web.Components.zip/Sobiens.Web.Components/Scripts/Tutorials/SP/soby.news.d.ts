declare function soby_PopulateSPNews(): void;
declare function soby_PopulateSPNewsImages(itemID: any): void;
