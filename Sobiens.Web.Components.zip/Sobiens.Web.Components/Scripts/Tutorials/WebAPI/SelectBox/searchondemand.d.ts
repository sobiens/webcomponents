declare function soby_PopulateSelectBoxSearchOnDemand(): void;
