declare function soby_PopulateSelectBoxGeneral(): void;
