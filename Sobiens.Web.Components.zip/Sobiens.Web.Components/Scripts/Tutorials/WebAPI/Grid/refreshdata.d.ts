declare function soby_PopulateGridEditing(): void;
