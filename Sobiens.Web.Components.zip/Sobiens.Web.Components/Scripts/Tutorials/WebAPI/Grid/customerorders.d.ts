declare function soby_PopulateGridCustomerOrders(): void;
declare function soby_PopulateCustomerAndOrderDetails(customerIds: any): void;
