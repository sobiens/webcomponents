declare function soby_PopulateGridRefreshData(): void;
