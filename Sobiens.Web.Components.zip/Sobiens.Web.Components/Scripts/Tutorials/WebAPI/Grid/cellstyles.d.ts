declare function soby_PopulateGridCellStyles(): void;
