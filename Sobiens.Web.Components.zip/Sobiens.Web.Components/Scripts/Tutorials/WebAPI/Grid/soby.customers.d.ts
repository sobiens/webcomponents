declare function soby_PopulateWebHeader(): void;
