declare function soby_PopulateGridCellTemplate(): void;
