declare var bookGrid: soby_WebGrid;
declare function soby_PopulateGridAggregates(): void;
