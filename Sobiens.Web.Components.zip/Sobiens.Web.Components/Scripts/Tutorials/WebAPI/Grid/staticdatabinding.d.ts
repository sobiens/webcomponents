declare function soby_PopulateGridStaticDataBinding(): void;
