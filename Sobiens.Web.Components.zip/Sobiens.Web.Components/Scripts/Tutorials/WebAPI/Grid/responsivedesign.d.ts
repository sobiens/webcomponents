declare function soby_PopulateGridResponsiveDesign(): void;
