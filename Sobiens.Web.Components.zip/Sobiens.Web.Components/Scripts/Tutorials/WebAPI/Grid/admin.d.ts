declare var soby_SchemaXml: any;
declare function soby_PopulateGridAdmin(): void;
declare function soby_PopulateEntitiesGrid(): void;
declare function soby_PopulateEntityGrid(entitySetName: any, entitySetType: any): void;
