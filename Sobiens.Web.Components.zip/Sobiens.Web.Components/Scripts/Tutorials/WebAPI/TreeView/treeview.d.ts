declare var treeView: soby_TreeView;
declare function soby_PopulateTreeView(): void;
