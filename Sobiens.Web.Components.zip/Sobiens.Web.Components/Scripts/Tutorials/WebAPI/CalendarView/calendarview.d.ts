declare var calendarView: soby_CalendarView;
declare function soby_PopulateCalendarView(): void;
