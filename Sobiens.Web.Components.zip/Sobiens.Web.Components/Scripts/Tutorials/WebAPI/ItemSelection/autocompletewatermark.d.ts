declare var itemSelection: soby_ItemSelection;
declare function soby_PopulateItemSelectionAutoCompleteWatermark(): void;
