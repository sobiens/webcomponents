declare function soby_PopulateRadarChartRefreshData(): void;
