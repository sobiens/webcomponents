declare function soby_PopulatePieChartRefreshData(): void;
