declare function soby_PopulateColumnChartRefreshData(): void;
