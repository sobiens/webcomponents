declare function soby_PopulatePolarAreaChartRefreshData(): void;
