declare function soby_PopulateBarChartRefreshData(): void;
