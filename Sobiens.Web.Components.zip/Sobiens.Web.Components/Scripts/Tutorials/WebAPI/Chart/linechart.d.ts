declare function soby_PopulateLineChartRefreshData(): void;
