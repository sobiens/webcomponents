declare function soby_PopulateWebNews(): void;
declare function soby_PopulateWebNewsImages(itemID: any): void;
