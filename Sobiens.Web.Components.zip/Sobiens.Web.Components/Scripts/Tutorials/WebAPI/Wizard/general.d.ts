declare function soby_PopulateGeneralWizard(): void;
