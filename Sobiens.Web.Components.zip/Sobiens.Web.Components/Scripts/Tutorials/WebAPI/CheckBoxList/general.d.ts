declare var financialYearCheckBoxList: SobyCheckBoxList;
declare function soby_PopulateCheckBoxList(): void;
