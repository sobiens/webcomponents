declare var itemSelection: SobyCheckBoxList;
declare function soby_PopulateCheckBoxList(): void;
