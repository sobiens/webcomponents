declare function soby_PopulateDataRepeaterPagingRefreshData(): void;
