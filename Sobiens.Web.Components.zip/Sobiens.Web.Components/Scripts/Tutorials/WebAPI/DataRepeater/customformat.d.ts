declare function soby_PopulateDataRepeaterCustomFormatRefreshData(): void;
