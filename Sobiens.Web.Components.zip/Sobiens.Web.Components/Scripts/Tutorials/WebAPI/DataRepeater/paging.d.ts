declare function soby_PopulateDataRepeaterRefreshData(): void;
