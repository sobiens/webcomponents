declare function soby_PopulateCustomizedCodeView1(): void;
