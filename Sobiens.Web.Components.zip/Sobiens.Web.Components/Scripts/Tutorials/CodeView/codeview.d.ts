declare var bookGrid: soby_WebGrid;
declare function soby_PopulateCodeView(): void;
