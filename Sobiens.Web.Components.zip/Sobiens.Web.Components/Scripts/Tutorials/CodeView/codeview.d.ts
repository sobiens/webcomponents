declare function soby_PopulateCustomizedCodeView(): void;
