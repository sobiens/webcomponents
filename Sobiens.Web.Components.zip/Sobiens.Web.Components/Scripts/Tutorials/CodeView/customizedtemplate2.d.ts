declare function soby_PopulateCustomizedCodeView2(): void;
