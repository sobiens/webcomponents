declare function soby_PopulateSelectBoxStaticDataBinding(): void;
