declare var scheduler: soby_Scheduler;
declare function soby_PopulateSchedulerCustomDates(): void;
declare function DisplayCustomDatesScheduleChanges(): void;
