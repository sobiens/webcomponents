declare var scheduler: soby_Scheduler;
declare function soby_PopulateScheduler(): void;
declare function DisplayScheduleChanges(): void;
