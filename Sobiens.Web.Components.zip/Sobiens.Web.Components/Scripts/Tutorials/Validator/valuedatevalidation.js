$(function () {
    var dateValidator = sobyValidate.GetValidator(soby_ValidatorTypes.Date);
    var isValid = dateValidator.Validate("12/12/2020");
    alert(isValid);
});
//# sourceMappingURL=valuedatevalidation.js.map