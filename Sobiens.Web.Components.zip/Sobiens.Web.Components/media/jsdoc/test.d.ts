/**
 * Class representing a dot.
 */
declare class soby_test {
}
