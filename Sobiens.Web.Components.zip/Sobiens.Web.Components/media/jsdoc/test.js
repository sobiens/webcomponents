/**
 * Class representing a dot.
 */
var soby_test = /** @class */ (function () {
    function soby_test() {
    }
    return soby_test;
}());
//# sourceMappingURL=test.js.map